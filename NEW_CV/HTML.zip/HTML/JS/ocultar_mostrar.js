function mostrar_ocultar() {
	
	document.getElementById('contenido').style.display="datos_basics";
	document.getElementById('datos_basics').style.display="none"; 

}